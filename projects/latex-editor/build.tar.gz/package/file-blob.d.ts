/// <reference types="node" />
export interface FileBlob {
    path: string;
    data: Buffer;
    contentType: string;
}
