import { SchematicContext, Tree } from '@angular-devkit/schematics';
import { Schema } from './schema';
interface NgAddOptions extends Schema {
    project: string;
}
export declare const ngAdd: (options: NgAddOptions) => (tree: Tree, _context: SchematicContext) => Promise<import("@angular-devkit/schematics/src/tree/interface").Tree>;
export {};
