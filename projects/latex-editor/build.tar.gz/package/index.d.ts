interface Options {
    workspaceConfig?: string;
    devTools?: boolean;
    allowIntegration?: boolean;
}
declare const _default: import("@angular-devkit/architect/src/internal").Builder<Options & import("@angular-devkit/core").JsonObject>;
export default _default;
