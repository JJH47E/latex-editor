export interface WorkspaceConfig {
    name: string;
    filePaths: string[];
}
