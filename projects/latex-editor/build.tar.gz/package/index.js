"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const architect_1 = require("@angular-devkit/architect");
const child_process_1 = require("child_process");
const path = require("path");
exports.default = (0, architect_1.createBuilder)((options, context) => {
    return new Promise(() => __awaiter(void 0, void 0, void 0, function* () {
        // create a target for building the app
        const buildTarget = {
            target: 'serve',
            project: context.target.project,
            configuration: options.workspaceConfig ? options.workspaceConfig : ''
        };
        // start building the app
        const build = yield context.scheduleTarget(buildTarget);
        const result = yield build.result;
        // find the path of the Electron binary and run it passing the shell.js as a parameter
        const electronPath = path.resolve('node_modules/.bin/electron');
        const appPath = path.resolve('node_modules/ngx-electronify/shell.js');
        // the port of the Angular Live Development Server is passed to the Electron window
        // so that it knows exactly which URL should load
        const port = result.port;
        // the following parameters are checked in that way because we explicitly want to have a boolean value.
        // If the user passes a string, we assume that it is a boolean value
        const devTools = options.devTools != null && `${options.devTools}` !== 'false';
        const allowIntegration = options.allowIntegration != null &&
            `${options.allowIntegration}` !== 'false';
        console.log('spawning child process');
        (0, child_process_1.spawn)(electronPath, [appPath, port, devTools.toString(), allowIntegration.toString()], {
            shell: true,
            stdio: "inherit"
        });
    }));
});
//# sourceMappingURL=index.js.map