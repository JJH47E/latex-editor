"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const promises_1 = require("node:fs/promises");
const electron_devtools_installer_1 = require("electron-devtools-installer");
const node_fs_1 = require("node:fs");
const AdmZip = require("adm-zip");
const path = require("node:path");
const node_constants_1 = require("node:constants");
const node_child_process_1 = require("node:child_process");
var mime = require('mime-types');
const ANGULAR_DEVTOOLS = 'ienfalfjdbdpebioblfackkekamfmbnh';
const [port, devTools, allowIntegration] = process.argv.slice(2);
const appUrl = `http://localhost:${port}/`;
const workingDirectory = './.tmp/active';
const templateDirectory = './templates';
const binDirectory = './bin';
const workspaceFilters = [
    {
        name: 'TeXProject',
        extensions: ['texproj']
    }
];
const pdfFilters = [
    {
        name: 'PDF',
        extensions: ['pdf']
    }
];
let workspacePath = '';
function createWindow() {
    const options = {
        width: 800,
        height: 600,
        show: false
    };
    // expose the Electron API into the global window object
    if (getBoolean(allowIntegration)) {
        options.webPreferences = {
            contextIsolation: false,
            nodeIntegration: true
        };
    }
    const mainWindow = new electron_1.BrowserWindow(options);
    // load the URL of the Angular Live Development Server
    mainWindow.loadURL(appUrl);
    mainWindow.once('ready-to-show', () => {
        mainWindow.show();
        if (getBoolean(devTools)) {
            mainWindow.webContents.openDevTools();
        }
    });
}
function installAngularDevtools() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const name = yield (0, electron_devtools_installer_1.default)(ANGULAR_DEVTOOLS);
            console.log(`Added Extension:  ${name}`);
        }
        catch (err) {
            console.log('An error occurred when downloading the extension: ', err);
        }
    });
}
electron_1.app.whenReady().then(() => __awaiter(void 0, void 0, void 0, function* () {
    yield installAngularDevtools();
    console.log('setting up handlers');
    electron_1.ipcMain.on('createWorkspace', (event, workspaceName) => __awaiter(void 0, void 0, void 0, function* () {
        yield createWorkspace(workspaceName, 'test_template.tex');
        event.sender.send('loadWorkspace-reply', yield getConfigContents(workingDirectory));
    }));
    electron_1.ipcMain.on('selectWorkspace', (event) => __awaiter(void 0, void 0, void 0, function* () {
        var paths = (yield selectWorkspace()).filePaths;
        if (paths.length > 1) {
            throw Error('Prompt should not be multi-select');
        }
        else if (paths.length == 0) {
            console.log('no file selected, returning');
            return;
        }
        console.log(`file selected, path: ${paths[0]}`);
        workspacePath = paths[0];
        event.sender.send('selectWorkspace-reply', paths[0]);
    }));
    electron_1.ipcMain.on('loadWorkspace', (event, relativePath) => __awaiter(void 0, void 0, void 0, function* () {
        console.log(`loading workspace: ${relativePath}`);
        var workingPath = yield loadWorkspace(relativePath);
        console.log(`ABSOLUTE PATH: ${workingPath}`);
        event.sender.send('loadWorkspace-reply', yield getConfigContents(workingPath));
    }));
    electron_1.ipcMain.on('getFile', (event, path) => __awaiter(void 0, void 0, void 0, function* () {
        console.log(`loading file: ${path}`);
        let fileBlob = yield getFileContents(path);
        console.log(`loaded file: ${path}, returning to renderer process`);
        event.returnValue = fileBlob;
    }));
    electron_1.ipcMain.on('saveFileAsync', (event, fileToSave, newFileToLoad) => __awaiter(void 0, void 0, void 0, function* () {
        console.log(`recieved request to save file: ${fileToSave.path}`);
        yield writeFileToDisk(fileToSave);
        event.sender.send('saveFileAsync-reply', newFileToLoad);
    }));
    electron_1.ipcMain.on('saveFile', (event, fileToSave, newFileToLoad) => __awaiter(void 0, void 0, void 0, function* () {
        console.log(`recieved request to save file: ${fileToSave.path}`);
        yield writeFileToDisk(fileToSave);
        event.returnValue = newFileToLoad;
    }));
    electron_1.ipcMain.on('saveWorkspace', (event) => __awaiter(void 0, void 0, void 0, function* () {
        console.log(`recieved request to save workspace. current loaded directory: ${workspacePath}`);
        if (workspacePath) {
            yield saveWorkspace(workspacePath);
        }
        else {
            let configContents = yield getConfigContents(workingDirectory);
            let savePath = yield openSavePrompt(configContents.name, workspaceFilters);
            if (!savePath) {
                console.log('Save aborted');
                return;
            }
            console.log(`saving to: ${savePath}`);
            yield saveWorkspace(workspacePath, savePath);
        }
        event.sender.send('saveWorkspace-reply', true);
    }));
    electron_1.ipcMain.on('saveWorkspaceAs', (event) => __awaiter(void 0, void 0, void 0, function* () {
        let configContents = yield getConfigContents(workingDirectory);
        let savePath = yield openSavePrompt(configContents.name, workspaceFilters);
        if (!savePath) {
            console.log('Save aborted');
            return;
        }
        console.log(`saving to: ${savePath}`);
        yield saveWorkspace(workspacePath, savePath);
        event.sender.send('saveWorkspace-reply', true);
    }));
    electron_1.ipcMain.on('generatePreview', (event) => __awaiter(void 0, void 0, void 0, function* () {
        // compile doc
        yield generatePreview(event);
    }));
    electron_1.ipcMain.on('downloadPdf', (event) => __awaiter(void 0, void 0, void 0, function* () {
        yield generatePreview(event);
        let configContents = yield getConfigContents(workingDirectory);
        let savePath = yield openSavePrompt(configContents.name, pdfFilters);
        if (!savePath) {
            console.log('Save aborted');
            return;
        }
        console.log(`saving to: ${savePath}`);
        yield saveFile((yield getFileContents('main.pdf')).data, savePath);
    }));
    createWindow();
}));
electron_1.app.on('web-contents-created', (_, contents) => {
    // Angular router is ignored on `will-navigate` event
    contents.on('will-navigate', (event, url) => {
        // allow hot reload to work properly
        if (url !== appUrl) {
            event.preventDefault();
        }
    });
    contents.setWindowOpenHandler(({ url }) => {
        // open all blank href links using the OS default browser
        setImmediate(() => {
            electron_1.shell.openExternal(url);
        });
        return { action: 'deny' };
    });
});
function getBoolean(value) {
    return value === 'true' ? true : false;
}
function createWorkspace(name, template) {
    return __awaiter(this, void 0, void 0, function* () {
        yield refreshWorkingDirectory();
        console.log(`creating workspace, ${name}, directory: ${workingDirectory}`);
        // create .config & save to working directory & copy main.tex from template
        const workspaceConfig = { name, filePaths: ['main.tex'] };
        yield copyTemplate(template, 'main.tex');
        yield (0, promises_1.writeFile)(`${workingDirectory}/.config`, JSON.stringify(workspaceConfig));
    });
}
function copyTemplate(template, destFileName) {
    return __awaiter(this, void 0, void 0, function* () {
        yield (0, promises_1.copyFile)(`${templateDirectory}/${template}`, `${workingDirectory}/${destFileName}`, node_constants_1.COPYFILE_EXCL);
    });
}
function selectWorkspace() {
    return __awaiter(this, void 0, void 0, function* () {
        return yield electron_1.dialog.showOpenDialog({ filters: workspaceFilters, properties: ['openFile'] });
    });
}
function refreshWorkingDirectory() {
    return __awaiter(this, void 0, void 0, function* () {
        if ((0, node_fs_1.existsSync)(workingDirectory)) {
            yield (0, promises_1.rm)(workingDirectory, { recursive: true, force: true });
        }
        yield (0, node_fs_1.mkdirSync)(workingDirectory, { recursive: true });
    });
}
function loadWorkspace(relativePath) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!relativePath) {
            throw Error(`Invalid path: ${relativePath}`);
        }
        var zip = new AdmZip(relativePath);
        yield refreshWorkingDirectory();
        zip.extractAllTo(workingDirectory, true);
        return path.resolve(workingDirectory);
    });
}
function getConfigContents(path) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const data = yield (0, promises_1.readFile)(`${path}/.config`, { encoding: 'utf8' });
            return JSON.parse(data);
        }
        catch (err) {
            console.log(err);
            return {};
        }
    });
}
function getFileContents(relativePath) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const filePath = path.resolve(`${workingDirectory}/${relativePath}`);
            const data = yield (0, promises_1.readFile)(filePath, { encoding: 'base64' });
            return { path: relativePath, data: Buffer.from(data, 'base64'), contentType: mime.contentType(filePath) };
        }
        catch (err) {
            console.log(err);
            return {};
        }
    });
}
function getFileContentsSync(relativePath) {
    try {
        const filePath = path.resolve(`${workingDirectory}/${relativePath}`);
        const data = (0, node_fs_1.readFileSync)(filePath, { encoding: 'base64' });
        return { path: relativePath, data: Buffer.from(data, 'base64'), contentType: mime.contentType(filePath) };
    }
    catch (err) {
        console.log(err);
        return {};
    }
}
function writeFileToDisk(fileToSave) {
    return __awaiter(this, void 0, void 0, function* () {
        var pathToWrite = path.resolve(`${workingDirectory}/${fileToSave.path}`);
        yield (0, promises_1.writeFile)(pathToWrite, Buffer.from(fileToSave.data), { encoding: 'base64' });
    });
}
function saveWorkspace(workspacePath, destinationPath = '') {
    return __awaiter(this, void 0, void 0, function* () {
        var zip = new AdmZip();
        // add config to zip
        let worksapceConfig = yield (0, promises_1.readFile)(`${workingDirectory}/.config`, 'utf-8');
        const _workspaceConfig = JSON.parse(worksapceConfig);
        var configBuffer = Buffer.from(worksapceConfig);
        zip.addFile('.config', configBuffer);
        for (var path of _workspaceConfig.filePaths) {
            console.log(`Adding ${path}`);
            var buffer = Buffer.from(yield (0, promises_1.readFile)(`${workingDirectory}/${path}`, { encoding: 'base64' }), 'base64');
            zip.addFile(path, buffer);
        }
        yield zip.writeZipPromise(!!destinationPath ? destinationPath : workspacePath);
    });
}
function saveFile(buffer, destinationPath) {
    return __awaiter(this, void 0, void 0, function* () {
        return yield (0, promises_1.writeFile)(destinationPath, buffer);
    });
}
function openSavePrompt(title, fileFilters) {
    return __awaiter(this, void 0, void 0, function* () {
        var saveResult = yield electron_1.dialog.showSaveDialog({ title, filters: fileFilters });
        if (!!saveResult.filePath) {
            return saveResult.filePath;
        }
        else {
            return '';
        }
    });
}
function doesFileExist(filePath) {
    return (0, node_fs_1.existsSync)(filePath);
}
function generatePreview(event) {
    return __awaiter(this, void 0, void 0, function* () {
        if (!doesFileExist(`${workingDirectory}/main.tex`)) {
            console.log('Unable to find main.tex in given directory, exiting...');
            event.sender.send('generatePreview-error', 'main.tex not found');
            return;
        }
        console.log('Starting generate preview process');
        (0, node_child_process_1.exec)(path.resolve(`${binDirectory}/pdflatex.bat ${path.resolve(workingDirectory)}`), (error, _, stderr) => {
            if (error || stderr) {
                console.log('error, returning');
                event.sender.send('generatePreview-error', stderr);
                return;
            }
            console.log('Finished successfully');
            if ((0, node_fs_1.existsSync)(`${workingDirectory}/main.log`)) {
                (0, node_fs_1.rmSync)(`${workingDirectory}/main.log`, { force: true });
            }
            if ((0, node_fs_1.existsSync)(`${workingDirectory}/main.aux`)) {
                (0, node_fs_1.rmSync)(`${workingDirectory}/main.aux`, { force: true });
            }
            let fileBlob = getFileContentsSync('main.pdf');
            console.log('file contents read successfuly, returning');
            event.sender.send('generatePreview-reply', fileBlob);
            return;
        });
    });
}
//# sourceMappingURL=shell.js.map