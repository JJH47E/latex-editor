"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const electron_1 = require("electron");
const uuid_1 = require("uuid");
const electron_devtools_installer_1 = require("electron-devtools-installer");
const ANGULAR_DEVTOOLS = 'ienfalfjdbdpebioblfackkekamfmbnh';
const [port, devTools, allowIntegration] = process.argv.slice(2);
const appUrl = `http://localhost:${port}/`;
const fs = require('fs');
const id = (0, uuid_1.v4)();
function createWindow() {
    const options = {
        width: 800,
        height: 600,
        show: false
    };
    // expose the Electron API into the global window object
    if (getBoolean(allowIntegration)) {
        options.webPreferences = {
            contextIsolation: false,
            nodeIntegration: true
        };
    }
    const mainWindow = new electron_1.BrowserWindow(options);
    // load the URL of the Angular Live Development Server
    mainWindow.loadURL(appUrl);
    mainWindow.once('ready-to-show', () => {
        mainWindow.show();
        if (getBoolean(devTools)) {
            mainWindow.webContents.openDevTools();
        }
    });
}
function installAngularDevtools() {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            const name = yield (0, electron_devtools_installer_1.default)(ANGULAR_DEVTOOLS);
            console.log(`Added Extension:  ${name}`);
        }
        catch (err) {
            console.log('An error occurred when downloading the extension: ', err);
        }
    });
}
electron_1.app.whenReady().then(() => __awaiter(void 0, void 0, void 0, function* () {
    yield installAngularDevtools();
    console.log('setting up handlers');
    electron_1.ipcMain.on('createWorkspace', (_, workspaceName) => {
        createWorkspace(workspaceName);
    });
    electron_1.ipcMain.on('openWorkspace', (event) => __awaiter(void 0, void 0, void 0, function* () {
        var paths = (yield openWorkspace()).filePaths;
        console.log(`file selected, path: ${paths.join(', ')}`);
        event.sender.send('openWorkspace-reply', paths);
    }));
    createWindow();
}));
electron_1.app.on('web-contents-created', (_, contents) => {
    // Angular router is ignored on `will-navigate` event
    contents.on('will-navigate', (event, url) => {
        // allow hot reload to work properly
        if (url !== appUrl) {
            event.preventDefault();
        }
    });
    contents.setWindowOpenHandler(({ url }) => {
        // open all blank href links using the OS default browser
        setImmediate(() => {
            electron_1.shell.openExternal(url);
        });
        return { action: 'deny' };
    });
});
function getBoolean(value) {
    return value === 'true' ? true : false;
}
function createWorkspace(name) {
    const dir = '.tmp/' + id;
    console.log(`creating workspace, ${name}, id: ${id}, directory: ${dir}`);
    if (fs.existsSync(dir)) {
        throw Error(`directory: ${dir} already exists`);
    }
    fs.mkdirSync(dir, { recursive: true });
    console.log('created directory');
    // Create main.tex & .config (refer to notes)
}
function openWorkspace() {
    return __awaiter(this, void 0, void 0, function* () {
        return yield electron_1.dialog.showOpenDialog({ properties: ['openFile'] });
    });
}
//# sourceMappingURL=shell.js.map